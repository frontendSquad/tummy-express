 <!-- ///////////////////////////////////////////////////////////////s/////////////--> 

 <!--logout-modal Modal start -->

<div class="default-modal modal-with-two-btns modal fade logout-modal"  tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i aria-hidden="true" class="fa fa-times"></i>
        </button>
      <div class="modal-body text-center">
		  <img src="images/inactive_img.png" class="img-fluid" alt="Check Image">
		  <h4 class="h2 nunito font-weight-bold mt-2">Logout</h4>
        <h6>Are You Sure You Want To Logout?</h6>
		<a href="login.php" class="gd-btn">yes</a>
		<button class="white-btn" data-dismiss="modal" aria-label="Close">no</button> 
      </div>
    </div>
  </div>
</div>

<!--logout-modal Modal end -->



<!-- BEGIN VENDOR JS--> 

<script src="app-assets/vendors/js/vendors.min.js" type="text/javascript"></script> 
<script src="app-assets/vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script> 
<script src='https://foliotek.github.io/Croppie/croppie.js'></script>
<script src="app-assets/js/scripts/tables/datatables/datatable-basic.js" type="text/javascript"></script> 
<script src="app-assets/vendors/js/charts/chart.min.js" type="text/javascript"></script> 
<script src="app-assets/vendors/js/charts/echarts/echarts.js" type="text/javascript"></script> 
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script> 
<script src="app-assets/js/scripts/charts/echarts/bar-column/basic-column.js" type="text/javascript"></script> 
<script src="app-assets/js/scripts/charts/echarts/pie-doughnut/basic-pie.js" type="text/javascript"></script>
<script src="assets/js/chart.js" type="text/javascript"></script> 
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="app-assets/vendors/js/charts/echarts/echarts.js" type="text/javascript"></script> 
<script src="app-assets/vendors/js/extensions/moment.min.js" type="text/javascript"></script> 
<script src="app-assets/vendors/js/extensions/fullcalendar.min.js" type="text/javascript"></script> 
<script src="app-assets/js/scripts/extensions/fullcalendar.js" type="text/javascript"></script> 
<script src="app-assets/js/core/app-menu.js" type="text/javascript"></script> 
<script src="app-assets/js/core/app.js" type="text/javascript"></script> 
<script src="app-assets/js/scripts/customizer.js" type="text/javascript"></script> 
<script src="app-assets/js/scripts/modal/components-modal.js" type="text/javascript"></script>
<script src="assets/js/function.js" type="text/javascript"></script> 

<!-- BEGIN VENDOR JS--> 
<!-- BEGIN VENDOR JS--> 
<!-- BEGIN PAGE VENDOR JS--> 
<!-- END PAGE VENDOR JS--> 
<!-- BEGIN STACK JS-->
</body>
</html>