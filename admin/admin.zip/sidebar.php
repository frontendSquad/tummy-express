<div class="main-menu menu-fixed menu-light menu-accordion" data-scroll-to-active="true">
	<div class="main-menu-content">
		<ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
			<li class="nav-item"><a href="dashboard.php"><i class="fas fa-th-large"></i><span class="menu-title" data-i18n="">Dashboard</span></a> </li>

			<li class="nav-item ">
				<a href="javascript:;"><i class="fas fa-archive"></i><span class="menu-title" data-i18n="">Menu</span></a>
				<ul class="menu-content">
					<li><a href="menu-items.php">Menu Items</a></li>
					<li><a href="category.php">Categories</a></li>
				</ul>
			</li>
			<li class="nav-item ">
				<a href="javascript:;"><i class="fas fa-cog"></i><span class="menu-title" data-i18n="">Order Management</span></a>
				<ul class="menu-content">
					<li><a href="orders.php">Orders</a></li>
					<li><a href="payments.php">Payments</a></li>
				</ul>				
			</li>
			<li class="nav-item "><a href="contact-us.php"><i class="fas fa-comment-alt"></i><span class="menu-title" data-i18n="">Contact Us</span></a></li>
		</ul>
	</div>
</div>














		